Assignment 2
Taylor Fahlman, Anthony Miller

Requires python 2

1. Run `python a2.py` or `./a2.py`
